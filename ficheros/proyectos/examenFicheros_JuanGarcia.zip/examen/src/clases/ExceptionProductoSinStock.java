package clases;

public class ExceptionProductoSinStock extends Exception {
  public ExceptionProductoSinStock(String message) {
    super(message);
  }
}
