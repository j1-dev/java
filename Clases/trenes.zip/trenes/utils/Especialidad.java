package Clases.trenes.utils;

public enum Especialidad {
  FRENOS, HIDRAULICA, ELECTRICIDAD, MOTOR
}
